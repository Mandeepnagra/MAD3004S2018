//
//  Student.swift
//  ErrorHandling
//
//  Created by MacStudent on 2018-07-25.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import Foundation

//final class Student{
class Student{
    var name : String?
    static var accNo: Int?
    static var countSt = 0
    
    init() {
        self.name = "Unknown"
        Student.accNo = 123456
        Student.countSt += 1
    }
    
    func display(){
        print("Student Name :  \(self.name ?? "unknown")")
        print("Fees Account Number :  \(Student.accNo ?? 000)")
        
    }
    
    static func getStudentCount() -> Int{
        return countSt
    }
    
}

class PartTime: Student {
    var hours: Int?
    
    override init() {
        super.init()
        self.hours = 10
    }
    
    override func display() {
        print("Hours : \(self.hours ?? 40)")
    }
    
}
