//
//  main.swift
//  ErrorHandling
//
//  Created by MacStudent on 2018-07-25.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import Foundation

print("Hello, World!")

var request1 = RequestLimitIncrease()

//do{
//    try request1.increaseLimit(accountNo: "S1300")
//}catch limitIncreaseError.ineligible{
//    print("You must have an Account with our Bank")
//}catch limitIncreaseError.noSavingAccount{
//    print("Sorry..Limit incresese is provided only to the Saving account Holders.")
//}catch limitIncreaseError.insufficientBalance{
//    print("Minimum $5000 balance is required for credit limit Increase")
//}catch{
//    print("Something unexpected happen.. Sorry for service distruption")
//}

//do{
//    try request1.increaseLimit(accountNo: "S1300")
//}catch is limitIncreaseError{
//    print("You donot match any of the following criteria for credit limit increase")
//    print("1. No account with our bank \n2. No Saving Account\n3. Insuffiecient Balance in Savings Account minimum $5000 required)")
//}
//catch is transactionError{
//
//}


var s1 = Student()
s1.name = "MK"
//Student.accNo = 123456
s1.display()


print("Account Number : \(Student.accNo!)")


var s2 = Student()
print("Student Count : \(Student.getStudentCount())")

var s3 = PartTime()
s3.display()
print("Student Count Full-Time + Part-Time : \(PartTime.getStudentCount())")


var s4 = Student()
s4.name = "Mandeep"
s4.display()

s4 = PartTime()
s4.display()


//s3 = s1 as! PartTime
//s3.display()






















